-This is an assignment that I worked on for my Artificial Intelligence class.
-It uses various search methods to find a '*' token in a given maze.
-This program will run best in an IDE such as eclipse as it prints out interesting information to standard output.
 However, it will also print out some stats to Output.txt in the Assignment1 directory. 
-The program takes no arguments to run.